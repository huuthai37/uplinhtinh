#include "corpus.hpp"
#include "MostPopular.hpp"
#include "BPRMF.hpp"
#include "MC.hpp"
#include "FPMC.hpp"
#include "HRM_max.hpp"
#include "HRM_avg.hpp"
#include "PRME.hpp"
#include "TransRec.hpp"
#include "TransRec_L1.hpp"


void go_MP(corpus* corp)
{
	MostPopular md(corp);
	double valid; md.MultipleMetrics(50, false, valid);
}

void go_BPRMF(corpus* corp, int K, double lambda, double bias_reg, int iterations, const char* model_path)
{
	BPRMF md(corp, K, lambda, bias_reg);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_MC(corpus* corp, int K, double lambda, int iterations, const char* model_path)
{
	MC md(corp, K, lambda);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_FPMC(corpus* corp, int K, int KK, double lambda, double bias_reg, int iterations, const char* model_path) 
{
	FPMC md(corp, K, KK, lambda);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_HRM_max(corpus* corp, int K, double lambda, double bias_reg, int iterations, const char* model_path) 
{
	HRM_max md(corp, K, lambda);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_HRM_avg(corpus* corp, int K, double lambda, double bias_reg, int iterations, const char* model_path) 
{
	HRM_avg md(corp, K, lambda);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_PRME(corpus* corp, int K, int KK, double alpha, double lambda, int iterations, const char* model_path) 
{
	PRME md(corp, K, KK, alpha, lambda);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_TransRec(corpus* corp, int K, double lambda, double relation_reg, double bias_reg, int iterations, const char* model_path) 
{
	TransRec md(corp, K, lambda, relation_reg, bias_reg);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}

void go_TransRec_L1(corpus* corp, int K, double lambda, double relation_reg, double bias_reg, int iterations, const char* model_path) 
{
	TransRec_L1 md(corp, K, lambda, relation_reg, bias_reg);
	md.init();
	md.train(iterations, 0.05);
	double valid; md.MultipleMetrics(50, false, valid);
	md.saveModel((string(model_path) + "__" + md.toString() + ".txt").c_str());
	md.cleanUp();
}


// Amazon data can be downloaded from http://jmcauley.ucsd.edu/data/amazon/ (under "Per-category files").
// You can run the program like ./train reviews_Automotive.simple.gz 5 5 10 0.1 0.1 0.01 0 10000 my_model_path_blah_blah
int main(int argc, char** argv)
{
	srand(0);
	
	if (argc != 11) {
		printf(" Parameters as following: \n");
		printf(" 1. Click triples path \n");
		printf(" 2. user min \n");
		printf(" 3. item min \n");

		printf(" 4. Latent Feature Dimension (K) \n");
		printf(" 5. lambda (L2-norm regularizer) \n");
		printf(" 6. relation_reg (L2-norm regularizer for USER translation vectors) \n");
		printf(" 7. bias_reg (L2-norm regularizer for bias terms) \n");
		printf(" 8. alpha (for PRME) \n");

		printf(" 9. Maximum number of iterations \n");
		printf("10. Model path \n\n");

		exit(1);
	}

	char* data_path = argv[1];
	int user_min = atoi(argv[2]);
	int item_min = atoi(argv[3]);
	int K  = atoi(argv[4]);
	double lambda = atof(argv[5]);
	double relation_reg = atof(argv[6]);
	double bias_reg = atof(argv[7]);
	double alpha = atof(argv[8]);
	int iter = atoi(argv[9]);
	char* model_path = argv[10];

	printf("{\n");
	printf("  \"corpus\": \"%s\",\n", data_path);

	corpus corp;
	corp.loadData(data_path, user_min, item_min);

	// go_MP(&corp);
	// go_BPRMF(&corp, K, lambda, bias_reg, iter, model_path);
	// go_MC(&corp, K, lambda, iter, model_path);
	// go_FPMC(&corp, K, K, lambda, bias_reg, iter, model_path);
	// go_HRM_max(&corp, K, lambda, bias_reg, iter, model_path);
	// go_HRM_avg(&corp, K, lambda, bias_reg, iter, model_path);
	go_PRME(&corp, K, K, alpha, lambda, iter, model_path);
	// go_TransRec(&corp, K, lambda, relation_reg, bias_reg, iter, model_path);

	printf("}\n");
	return 0;
}
