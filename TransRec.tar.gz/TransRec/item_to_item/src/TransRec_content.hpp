#pragma once

#include "TransRec.hpp"


class TransRec_content : public TransRec
{
public:
	TransRec_content( corpus* corp, int K, int N, double lambda, double relation_reg) 
					: TransRec(corp, K, N, lambda)
					, relation_reg(relation_reg) {}

	~TransRec_content() {}

	void init();
	void clean_up();

	void parameters_from_flat(	double*    g,
								double***  E,
								double***  R,
								action_t   action);

	double distance(int productFrom, int productTo);

	void optimize_embeddings(double learn_rate);

	void mapToKSpace();
	void print();

	void trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
							double& train_hit, double& valid_hit, double& test_hit, int POS, 
							bool sample);
	string toString();

	/* Parameters */
	double** E;  // Embedding matrix

	/* Hyper-parameters */
	double relation_reg;

	/* Helper */
	double** k_space;
};
