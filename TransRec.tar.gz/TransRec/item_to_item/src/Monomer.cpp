#include "Monomer.hpp"

extern Monomer* gtc;

void Monomer::init()
{
	gtc = this;

	// Total number of parameters
	NW = 1 + featureDim * K * (N + 1) + featureDim * N;

	W = new double [NW];
	parameters_from_flat(W, &c, &E, &T, INIT);

	// Initialize parameters
	W[0] = 0;
	for (int i = 1; i < NW; i++) {
		W[i] = 1.0 - 2.0 * rand() / RAND_MAX;
	}

	bestValidModel = new double [NW];
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}

	// Low-dimensional spaces (visual spaces)
	k_space = new double** [N + 1];
	for (int n = 0; n < N + 1; n ++) {
		k_space[n] = new double* [nItems];
		for (int i = 0; i < nItems; i ++) {
			k_space[n][i] = new double [K];
		}
	}

	printf("==== %s ====\n", toString().c_str());
}

void Monomer::clean_up()
{
	parameters_from_flat(0, &c, &E, &T, FREE);

	delete [] W;
	delete [] bestValidModel;
	for (int n = 0; n < N + 1; n ++) {
		for (int i = 0; i < nItems; i ++) {
			delete [] k_space[n][i];
		}
		delete [] k_space[n];
	}
	delete [] k_space;
}

void Monomer::parameters_from_flat(	double*    g,
									double**   c,
									double**** E,
									double***  T,
									action_t   action)
{
	if (action == FREE) {
		for (int n = 0; n < N; n ++) {
			delete [] (*E)[n];
		}
		delete [] *E;
		delete [] *T;
		return;
	}

	if (action == INIT) {
		*E = new double** [N + 1];
		for (int n = 0; n < N + 1; n ++) {
			(*E)[n] = new double* [K];
		}
		*T = new double* [N];
	}

	int ind = 0;

	*c = g + ind;
	ind ++;

	for (int n = 0; n < N + 1; n ++) {
		for (int k = 0; k < K; k ++) {
			(*E)[n][k] = g + ind;
			ind += featureDim;
		}
	}

	for (int n = 0; n < N; n ++) {
		(*T)[n] = g + ind;
		ind += featureDim;
	}

	if (ind != NW) {
		printf("Got incorrect index (%d != %d) at line %d of Monomer.cpp\n", ind, NW, __LINE__);
		exit(1);
	}
}

void Monomer::mapToKSpace()
{
	for (int n = 0; n < N + 1; n ++) {
		#pragma omp parallel for schedule(dynamic)
		for (int i = 0; i < nItems; i ++) {
			vector<pair<int, float> >& feat = corp->features[i];
			for (int k = 0; k < K; ++ k) {
				k_space[n][i][k] = 0;
				for (unsigned j = 0; j < feat.size(); j ++) {
					k_space[n][i][k] += E[n][k][feat[j].first] * feat[j].second;
				}
			}
		}
	}
}

double Monomer::distance(int productFrom, int productTo)
{
	vector<pair<int, float> >& f_x = corp->features[productFrom];

	double* ex = new double [N];
	for (int n = 0; n < N; n ++) {
		ex[n] = 0;
		for (unsigned i = 0; i < f_x.size(); i ++) {
			ex[n] += f_x[i].second * T[n][f_x[i].first];
		}
	}

	double sum_of_ex = 0;
	for (int n = 0; n < N; n ++) {
		ex[n] = exp(ex[n]);
		sum_of_ex += ex[n];
	}

	double dist = 0;
	for (int n = 0; n < N; n ++) {
		dist += ex[n] / sum_of_ex * l2(k_space[0][productFrom], k_space[n + 1][productTo], K);
	}

	delete [] ex;
	return dist;
}

/// Derivative of the log probability
double Monomer::l_dl(double* grad)
{
	double l_dlStart = clock_();

	mapToKSpace();

	int NT = omp_get_max_threads();

	// Separate gradient vectors for each thread
	double**   gradT = new double* [NT];
	double**   dC 	 = new double* [NT];
	double**** dE 	 = new double*** [NT];
	double***  dT 	 = new double** [NT];

	double* llThread = new double [NT];
	for (int t = 0; t < NT; t ++) {
		llThread[t] = 0;
	}

	for (int t = 0; t < NT; t ++) {
		gradT[t] = new double [NW];
		for (int w = 0; w < NW; w ++) {
			gradT[t][w] = 0;
		}
		parameters_from_flat(gradT[t], dC + t, dE + t, dT + t, INIT);
	}

	#pragma omp parallel for schedule(dynamic)
	for (int ind = 0; ind < (int)pos_neg_edges.size(); ind ++) {
		int tid = omp_get_thread_num();
		
		edge* e = pos_neg_edges[ind];

		int x = e->productFrom;
		int y = e->productTo;

		vector<pair<int, float> >& f_x = corp->features[x];
		vector<pair<int, float> >& f_y = corp->features[y];

		double* ex = new double [N];
		for (int n = 0; n < N; n ++) {
			ex[n] = 0;
			for (unsigned i = 0; i < f_x.size(); i ++) {
				ex[n] += f_x[i].second * T[n][f_x[i].first];
			}
		}

		double sum_of_ex = 0;
		for (int n = 0; n < N; n ++) {
			ex[n] = exp(ex[n]);
			sum_of_ex += ex[n];
		}

		double* dist = new double [N];
		for (int n = 0; n < N; n ++) {
			dist[n] = l2(k_space[0][x], k_space[n + 1][y], K);
		}

		double pred = *c;
		for (int n = 0; n < N; n ++) {
			pred -= ex[n] / sum_of_ex * dist[n];
		}

		if (e->label) llThread[tid] += pred;
		llThread[tid] -= safeLog(pred);

		double deri = e->label - 1 / (1 + exp(-pred));

		*(dC[tid]) += deri;

		double deri_AB = - deri / sum_of_ex / sum_of_ex;

		for (int i = 0; i < N; i ++) {
			double sum = 0;
			for (int n = 0; n < N; n ++) {
				if (n == i) {
					sum += dist[i] * ex[i] * (sum_of_ex - ex[i]);
				} else {
					sum += - dist[n] * ex[i] * ex[n]; 
				}
			}
			double deri_i = deri_AB * sum;
			for (vector<pair<int, float> >::iterator it = f_x.begin(); it != f_x.end(); it ++) {
				dT[tid][i][it->first] += deri_i * it->second;
			}
		}

		for (int n = 0; n < N; n ++) {
			double deri_E = - deri * 2 * ex[n] / sum_of_ex;

			// E_0
			for (int r = 0; r < K; r ++) {
				double deri_Er = deri_E * (k_space[0][x][r] - k_space[n + 1][y][r]);
				double* dEr = dE[tid][0][r];
				for (unsigned j = 0; j < f_x.size(); j ++) {
					int c = f_x[j].first;
					dEr[c] += deri_Er * f_x[j].second; 
				}
			}

			// E_n+1
			for (int r = 0; r < K; r ++) {
				double deri_Er = deri_E * (k_space[n + 1][y][r] - k_space[0][x][r]);
				double* dEr = dE[tid][n+1][r];
				for (unsigned j = 0; j < f_y.size(); j ++) {
					int c = f_y[j].first;
					dEr[c] += deri_Er * f_y[j].second; 
				}
			}
		}

		delete [] dist;
		delete [] ex;

		if (not ((ind + 1) % 100000)) {
			// Print progress so that you can see that something is happening...
			printf("-");
			fflush(stdout);
		}
	}

	double llTotal = 0;
	for (int t = 0; t < NT; t ++) {
		llTotal += llThread[t];
	}

	// Add up the gradients from all threads
	for (int w = 0; w < NW; w ++) {
		grad[w] = 0;
		for (int t = 0; t < NT; t ++) {
			grad[w] += gradT[t][w];
		}
	}

	for (int w = 1; w < NW; w ++) {
		llTotal -= lambda * W[w] * W[w];
		grad[w] -= 2 * lambda * W[w];
	}

	for (int t = 0; t < NT; t ++) {
		delete [] gradT[t];
		parameters_from_flat(0, dC + t, dE + t, dT + t, FREE);
	}

	delete [] llThread;
	delete [] gradT;
	delete [] dC;
	delete [] dE;
	delete [] dT;

	printf("took %f\n", clock_() - l_dlStart);

	return llTotal;
}

/// Compute the training, validation, and test error
void Monomer::trainValidTestAUC(double& train_AUC, double& valid_AUC, double& test_AUC, 
								double& train_hit, double& valid_hit, double& test_hit, int POS, 
								bool sample)
{
	mapToKSpace();
	model::trainValidTestAUC(train_AUC, valid_AUC, test_AUC, train_hit, valid_hit, test_hit, POS, sample);
}

string Monomer::toString()
{
	char str[10000];
	sprintf(str, "Monomer__K_%d_N_%d_lambda_%f", K, N, lambda);
	return str;
}