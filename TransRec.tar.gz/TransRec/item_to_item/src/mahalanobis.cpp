#include "mahalanobis.hpp"

extern mahalanobis* gtc;

void mahalanobis::init()
{
	gtc = this;

	// Total number of parameters
	NW = 1 + featureDim * featureDim;

	// Initialize parameters and latent variables
	W = new double [NW];
	for (int i = 0; i < NW; i++) {
		W[i] = 0;
	}

	parameters_from_flat(W, &c, &M, INIT);

	bestValidModel = new double [NW];
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}

	printf("==== %s ====\n", toString().c_str());
}

void mahalanobis::clean_up()
{
	parameters_from_flat(0, &c, &M, FREE);
	
	delete [] bestValidModel;
	delete [] W;
}

void mahalanobis::parameters_from_flat(	double*		g,
										double**	c,
										double***	M,
										action_t	action)
{
	if (action == FREE) {
		delete[] *M;
		return;
	}

	if (action == INIT) {
		*M = new double* [featureDim];
	}

	int ind = 0;

	*c = g + ind;
	ind ++;

	for (int f = 0; f < featureDim; f ++) {
		(*M)[f] = g + ind;
		ind += featureDim;
	}

	if (ind != NW) {
		printf("Got incorrect index (%d != %d) at line %d of mahalanobis.cpp\n", ind, NW, __LINE__);
		exit(1);
	}
}

double mahalanobis::distance(int productFrom, int productTo)
{
	vector<pair<int, double> > sparsity = diff_feature(productFrom, productTo);

	double dist = 0;
	for (auto i = sparsity.begin(); i != sparsity.end(); i ++) {
		for (auto j = sparsity.begin(); j != sparsity.end(); j ++) {
			dist += M[i->first][j->first] * i->second * j->second;
		}
	}

	return dist;
}

/// Derivative of the log probability
double mahalanobis::l_dl(double* grad)
{
	double l_dlStart = clock_();

	int NT = omp_get_max_threads();

	// Separate gradient vectors for each thread
	double**  gradT = new double* [NT];
	double**  dC = new double* [NT];
	double*** dM = new double** [NT];

	double* llThread = new double [NT];
	for (int t = 0; t < NT; t ++) {
		llThread[t] = 0;
	}

	for (int t = 0; t < NT; t ++) {
		gradT[t] = new double [NW];
		for (int w = 0; w < NW; w ++) {
			gradT[t][w] = 0;
		}
		parameters_from_flat(gradT[t], dC + t, dM + t, INIT);
	}

	#pragma omp parallel for schedule(dynamic)
	for (int ind = 0; ind < (int)pos_neg_edges.size(); ind ++) {
		int tid = omp_get_thread_num();
		
		edge* e = pos_neg_edges[ind];

		vector<pair<int, double> > sparsity = diff_feature(e->productFrom, e->productTo);

		double dist = 0;
		for (auto i = sparsity.begin(); i != sparsity.end(); i ++) {
			for (auto j = sparsity.begin(); j != sparsity.end(); j ++) {
				dist += M[i->first][j->first] * i->second * j->second;
			}
		}

		double pred = *c - dist;

		if (e->label) llThread[tid] += pred;
		llThread[tid] -= safeLog(pred);

		double deri = e->label - 1 / (1 + exp(-pred));

		*(dC[tid]) += deri;

		for (auto i = sparsity.begin(); i != sparsity.end(); i ++) {
			for (auto j = sparsity.begin(); j != sparsity.end(); j ++) {
				dM[tid][i->first][j->first] -= deri * i->second * j->second;
			}
		}		
	}

	double llTotal = 0;
	for (int t = 0; t < NT; t ++) {
		llTotal += llThread[t];
	}

	// Add up the gradients from all threads
	for (int w = 0; w < NW; w ++) {
		grad[w] = 0;
		for (int t = 0; t < NT; t ++) {
			grad[w] += gradT[t][w];
		}
	}

	for (int w = 1; w < NW; w ++) {
		llTotal -= lambda * W[w] * W[w];
		grad[w] -= 2 * lambda * W[w];
	}

	for (int t = 0; t < NT; t ++) {
		delete [] gradT[t];
		parameters_from_flat(0, dC + t, dM + t, FREE);
	}

	delete [] llThread;
	delete [] gradT;
	delete [] dC;
	delete [] dM;

	printf("took %f\n", clock_() - l_dlStart);

	return llTotal;
}

string mahalanobis::toString()
{
	char str[10000];
	sprintf(str, "Mahalanobis__lambda_%f", lambda);
	return str;
}
