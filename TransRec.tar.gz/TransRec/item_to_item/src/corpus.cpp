#include "corpus.hpp"


/// To sort words by frequency in a corpus
bool wordCountCompare(pair<string, int> p1, pair<string, int> p2)
{
	return p1.second > p2.second;
}

/// Sign (-1, 0, or 1)
template<typename T> int sgn(T val)
{
	return (val > T(0)) - (val < T(0));
}

static inline string &ltrim(string &s)
{
	s.erase(s.begin(), find_if(s.begin(), s.end(), not1(ptr_fun<int, int>(isspace))));
	return s;
}

// trim from end
static inline string &rtrim(string &s)
{
	s.erase(find_if(s.rbegin(), s.rend(), not1(ptr_fun<int, int>(isspace))).base(), s.end());
	return s;
}

// trim from both ends
static inline string &trim(string &s)
{
	return ltrim(rtrim(s));
}

corpus::corpus(	const char* featurePath, int dim, const char* categoryPath, vector<string> CTPath, int layer, 
				const char* graphPath,  const char* duplicatePath)
{
	FILE* fFile = fopen_(featurePath, "rb");

	char* asin = new char [11];
	asin[10] = '\0';

	nItems = 0;
	featureDim = dim;

	int a;
	printf("Loading features from %s", featurePath);

	double ma;
	if (featureDim == 4096) { // image feature only
		ma = 58.388599;
	} else {
		ma = 1.0;  // NOTE: must pre-normalize the image feature in mixed-feature case
	}

	float* feat = new float [featureDim];

	while (!feof(fFile)) {
		if ((a = fread(asin, sizeof(*asin), 10, fFile)) != 10) {
			// printf("Expected to read %d chars, got %d\n", 10, a);
			break;
		}
		for (int c = 0; c < 10; c ++) {
			if (not isascii(asin[c])) {
				printf("Expected asin to be 10-digit ascii\n");
				exit(1);
			}
		}

		if (not (nItems % 10000)) {
			printf(".");
			fflush(stdout);
		}

		if ((a = fread(feat, sizeof(*feat), featureDim, fFile)) != featureDim) {
			printf("Expected to read %d floats, got %d\n", featureDim, a);
			exit(1);
		}

		vector<pair<int, float> > vec;
		for (int f = 0; f < featureDim; f ++) {
			if (feat[f] != 0) {  // compression
				vec.push_back(make_pair(f, feat[f]/ma));
			}
		}
		features.push_back(vec);

		string sAsin(asin);

		itemIds[sAsin] = nItems;
		rItemIds[nItems] = sAsin;
		nItems ++;
	}
	printf("\n");

	delete [] asin;
	delete [] feat;
	fclose(fFile);

	printf("  \"nItems\": %d,\n", (int) features.size());

	loadCategories(categoryPath, CTPath, layer);
	loadGraph(graphPath, duplicatePath);

	printf("  Statistics: \"nItems\": %d, \"nCategories\": %d\n ", nItems, nCategory);
}

bool corpus::isValidPair(int itemA, int itemB)
{
	if (itemCategoryId[itemA] == -1 || itemCategoryId[itemB] == -1) {
		return false;
	}
	if (itemCategoryId[itemA] == itemCategoryId[itemB]) {
		return false;
	}
	return true;
}

void corpus::loadGraph(const char* graphPath, const char* duplicatePath)
{
	printf("Loading duplicate labels from %s", duplicatePath);
	map<string, string> duplicates;
	igzstream inDup;
	inDup.open(duplicatePath);
	if (!inDup.good()) {
		printf("duplicate read error!");
		exit(1);
	}
	string asin;
	string dupof;

	int count = 0;
	while (inDup >> asin >> dupof) {
		duplicates[asin] = dupof;
		count ++;
		if (not (count % 100000)) printf(".");
	}

	inDup.close();
	printf("\n");

	printf("Loading graph ");

	printf("  \"Graph\": {");

	igzstream in;
	in.open(graphPath);
	if (!in.good()) {
		printf("graphPath read error!");
		exit(1);
	}

	string n1;
	string n2;
	string edgename;

	string line;
	while (getline(in, line)) {
		stringstream ss(line);
		ss >> n1 >> edgename; // Second word of each line should be the edge type
		if (itemIds.find(n1) == itemIds.end()) {
			continue;
		}
		int iid1 = itemIds[n1];

		while (ss >> n2) {
			if (itemIds.find(n2) == itemIds.end()) {
				if (duplicates.find(n2) != duplicates.end()) {
					n2 = duplicates[n2];
				}
				if (itemIds.find(n2) == itemIds.end()) {
					continue;
				}
			}
			int iid2 = itemIds[n2];

			// Only keep edges connecting two different categories
			if (!isValidPair(iid1, iid2)) {
				continue;
			}

			productGraph.insert(make_pair(iid1,iid2));

			if (not (productGraph.size() % 10000)) {
				printf(".");
			}
		}
	}

	printf("\n");
	graphName = edgename;
	printf("\"%s\": %d", edgename.c_str(), (int) productGraph.size());

	printf("},\n");
}

/// Parse category info for all products
void corpus::loadCategories(const char* categoryPath, vector<string>& CTPath, int layer)
{
	for (int i = 0; i < nItems; i ++) {
		vector<string> v;
		productCategories[i] = v;
	}

	printf("Loading category data, category path = [");
	for (unsigned i = 0; i < CTPath.size(); i ++) {
		printf("%s", CTPath[i].c_str());
		if (i < CTPath.size() - 1) {
			printf(", ");
		}
	}

	printf("], ");
	printf("layer = %d ", layer);

	igzstream in;
	in.open(categoryPath);
	if (! in.good()) {
	fprintf(stderr, "\n  Can't load category from %s.\n", categoryPath);
	exit(1);
	}

	string line;

	int currentProduct = -1;
	int count = 0;
	while (getline(in, line)) {
		istringstream ss(line);

		if (line.c_str()[0] != ' ') {
			string itemId;
			double price = -1;
			string brand("unknown_brand");
			ss >> itemId;
			ss >> price >> brand;
			if (itemIds.find(itemId) == itemIds.end()) {
				currentProduct = -1; // Invalid product
			} else {
				currentProduct = itemIds[itemId];

				if (brand.compare("unknown_brand") != 0) {
					itemBrand[currentProduct] = brand;
				}
				if (price > 0) {
					itemPrice[currentProduct] = price;
				}
			}
			count ++;
			if (not (count % 100000)) {
				printf(".");
			}
			continue;
		}

		if (currentProduct == -1){
			continue;
		}

		if (productCategories[currentProduct].size() > 0) {
			continue;
		}

		vector<string> category;

		// Category for each product is a comma-separated list of strings
		string cat;
		while (getline(ss, cat, ',')) {
			category.push_back(trim(cat));
		}

		if (category.size() < layer + CTPath.size()) {
			continue;
		}

		bool pass = true;
		for (unsigned i = 0; i < CTPath.size(); i ++) {
			if (category[i] != CTPath[i]) {
				pass = false;
				break;
			}
		}

		if (! pass) {
			continue;
		}

		productCategories[currentProduct].push_back(CTPath.back()); // root
		for (int i = 0; i < layer; i ++) {
			productCategories[currentProduct].push_back(category[CTPath.size() + i]);
		}
	}

	in.close();

	nCategory = 0;
	itemCategoryId = new int [nItems];

	for (int i = 0; i < nItems; i ++) {
		if (productCategories[i].size() == 0) {
			itemCategoryId[i] = -1;
			continue;
		}

		string fullpath = "";
		for (int l = 0; l < layer + 1; l ++) {
			fullpath = fullpath + productCategories[i].at(l);
			if (l < layer) fullpath += "|";
		}

		if (nodeIds.find(fullpath) == nodeIds.end()) {
			nodeIds[fullpath] = nCategory;
			rNodeIds[nCategory] = fullpath;
			nCategory ++;
		}
		itemCategoryId[i] = nodeIds[fullpath];
	}

	int total = 0;
	for (int i = 0; i < nItems; i ++) {
		if (itemCategoryId[i] != -1) {
			total ++;
		}
	}

	printf("\n  #Items with category: %d\n", total);
	if (1.0 * total / nItems < 0.6) {
		printf("\n [Warning]: So few items are having category info. Sth wrong may have happened.\n");
	}
}

corpus::~corpus()
{
	delete [] itemCategoryId;
}