#pragma once

#include "common.hpp"


class corpus
{
public:
	corpus(const char* featurePath, int dim, const char* categoryPath, vector<string> CTPath, int layer, 
			const char* graphPath,  const char* duplicatePath);
	~corpus();

	bool isValidPair(int itemA, int itemB);
	void loadCategories(const char* categoryPath, vector<string>& CTPath, int layer);
	void loadGraph(const char* graphPath, const char* duplicatePath);

	int nItems; // Number of items

	unordered_map<string, int> itemIds; // Maps an item's string-valued ID to an integer
	unordered_map<int, string> rItemIds;

	string graphName;
	set<pair<int,int> > productGraph;

	unordered_map<int, vector<string> > productCategories; // Set of categories of each product (products can belong to multiple categories)
	unordered_map<int, string> itemBrand;
	unordered_map<int, double> itemPrice;

	vector<vector<pair<int,float> > > features;
	int featureDim; // Dimensionality of the features

	/* Category information */
	int  nCategory;
	int* itemCategoryId;
	unordered_map<string,int> nodeIds;
	unordered_map<int,string> rNodeIds;
};
