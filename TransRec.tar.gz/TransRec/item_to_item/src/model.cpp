#include "model.hpp"

/// Compute the training, validation, and test error
void model::trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
								double& train_hit, double& valid_hit, double& test_hit, int POS, 
								bool sample)
{
	int NT = omp_get_max_threads();

	double* train_AUC_thread = new double [NT];
	double* train_hit_thread = new double [NT];
	int* 	train_cnt_thread = new int [NT];

	double* valid_AUC_thread = new double [NT];
	double* valid_hit_thread = new double [NT];
	int* 	valid_cnt_thread = new int [NT];

	double* test_AUC_thread  = new double [NT];
	double* test_hit_thread  = new double [NT];
	int* 	test_cnt_thread  = new int [NT];

	for (int t = 0; t < NT; t ++) {
		train_AUC_thread[t] = valid_AUC_thread[t] = test_AUC_thread[t] = 0;
		train_hit_thread[t] = valid_hit_thread[t] = test_hit_thread[t] = 0;
		train_cnt_thread[t] = valid_cnt_thread[t] = test_cnt_thread[t] = 0;
	}

	#pragma omp parallel for schedule(dynamic)
	for (int ind = 0; ind < nEdges; ind ++) {

		if (ind < validStart) {
			if (rand() % 1000 != 0) {
				continue;
			}
		} else if (sample && rand() % 10 != 0) {
			continue;
		}		

		int tid = omp_get_thread_num();

		edge* e = edges[ind];

		double dist_gt = distance(e->productFrom, e->productTo);

		int count = 0;
		for (int j = 0; j < (int)valid_items.size(); j ++) {
			if (valid_items[j] == e->productTo) {
				continue;
			}

			if (dist_gt < distance(e->productFrom, valid_items[j])) {
				count ++;
			}
		}


		double auc = 1.0 * count / (valid_items.size() - 1);

		double hit = 0.0;
		if ((int)valid_items.size() - 1 - count <= POS) {
			hit = 1.0;
		}

		if (ind < validStart) {
			train_AUC_thread[tid] += auc; 
			train_cnt_thread[tid] ++;
			train_hit_thread[tid] += hit;
		} else if (ind < testStart) {
			valid_AUC_thread[tid] += auc; 
			valid_cnt_thread[tid] ++;
			valid_hit_thread[tid] += hit;
		} else {
			test_AUC_thread[tid] += auc;
			test_cnt_thread[tid] ++;
			test_hit_thread[tid] += hit;
		}
	}

	train_AUC = 0, valid_AUC = 0, test_AUC = 0;
	train_hit = 0, valid_hit = 0, test_hit = 0;
	int train_cnt = 0, valid_cnt = 0, test_cnt = 0;
	for (int t = 0; t < NT; t ++) {
		train_cnt += train_cnt_thread[t];
		valid_cnt += valid_cnt_thread[t];
		test_cnt += test_cnt_thread[t];

		train_AUC += train_AUC_thread[t];
		valid_AUC += valid_AUC_thread[t];
		test_AUC += test_AUC_thread[t];

		train_hit += train_hit_thread[t];
		valid_hit += valid_hit_thread[t];
		test_hit += test_hit_thread[t];
	}

	train_AUC /= train_cnt;
	valid_AUC /= valid_cnt;
	test_AUC /= test_cnt;

	train_hit /= train_cnt;
	valid_hit /= valid_cnt;
	test_hit /= test_cnt;

	delete [] train_AUC_thread;
	delete [] train_hit_thread;
	delete [] train_cnt_thread;
	delete [] valid_AUC_thread;
	delete [] valid_hit_thread;
	delete [] valid_cnt_thread;
	delete [] test_AUC_thread;
	delete [] test_hit_thread;
	delete [] test_cnt_thread;
}

void model::copyBestValidModel()
{
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}
}

void model::saveModel(const char* path)
{
	FILE* f = fopen_(path, "w");
	fprintf(f, "{\n");
	fprintf(f, "  \"NW\": %d,\n", NW);

	fprintf(f, "  \"W\": [");
	for (int w = 0; w < NW; w ++) {
		fprintf(f, "%f", bestValidModel[w]);
		if (w < NW - 1) 
			fprintf(f, ", ");
	}
	fprintf(f, "]\n");
	fprintf(f, "}\n");
	fclose(f);

	printf("\nModel saved to %s.\n", path);
}

/// Model must be first initialized before calling this function
void model::loadModel(const char* path)
{
	fprintf(stderr, "\n  loading parameters from %s.\n", path);
	
	ifstream in;
	in.open(path);
	if (! in.good()){
		fprintf(stderr, "Can't read init solution from %s.\n", path);
		exit(1);
	}

	string line;
	string st;
	char ch;
	while(getline(in, line)) {
		stringstream ss(line);
		ss >> st;
		if (st == "\"NW\":") {
			int nw;
			ss >> nw;
			if (nw != NW) {
				fprintf(stderr, "NW not match.");
				exit(1);
			}
			continue;
		}

		if (st == "\"W\":") {
			ss >> ch; // skip '['
			for (int w = 0; w < NW; w ++) {
				if (! (ss >> W[w] >> ch)) {
					fprintf(stderr, "Read W[] error.");
					exit(1);
				}
			}
			break;
		}
	}
	in.close();
}

string model::toString()
{
	return "Empty_model";
}

vector<pair<int, double> > model::diff_feature(int productFrom, int productTo)
{
	vector<pair<int, double> > sparsity;

	vector<pair<int, float> >& feat_i = corp->features[productFrom];
	vector<pair<int, float> >& feat_j = corp->features[productTo];

	unsigned p_i = 0, p_j = 0;
	while (p_i < feat_i.size() && p_j < feat_j.size()) {
		int ind_i = feat_i[p_i].first;
		int ind_j = feat_j[p_j].first;
		if (ind_i < ind_j) {
			sparsity.push_back(make_pair(ind_i, - feat_i[p_i].second));
			p_i ++;
		} else if (ind_i > ind_j) {
			sparsity.push_back(make_pair(ind_j, feat_j[p_j].second));
			p_j ++;
		} else {
			sparsity.push_back(make_pair(ind_i, feat_j[p_j].second - feat_i[p_i].second));
			p_i ++; p_j ++;
		}
	}
	while (p_i < feat_i.size()) {
		sparsity.push_back(make_pair(feat_i[p_i].first, - feat_i[p_i].second));
		p_i ++;
	}
	while (p_j < feat_j.size()) {
		sparsity.push_back(make_pair(feat_j[p_j].first, feat_j[p_j].second));
		p_j ++;
	}

	return sparsity;
}
