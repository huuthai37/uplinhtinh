#pragma once

#include <iostream>
#include <cstdlib>
#include <vector>
#include <cstring>
#include <omp.h>
#include <map>
#include <set>
#include <algorithm>
#include <sstream>
#include "gzstream.h"
#include <cfloat>
#include <unordered_set>
#include <unordered_map>
#include <ctype.h>
#include "sys/time.h"
#include <climits>
#include <cmath>

using namespace std;

enum action_t { INIT, COPY, FREE };
enum error_type { TRAIN, VALID, TEST };


class edge
{
public:
	edge(int productFrom, int productTo, int label) 
		: productFrom(productFrom)
		, productTo(productTo)
		, label(label) {} 

	~edge() {}

	int productFrom;
	int productTo;
	int label; // Is this an edge or a non-edge
};

/// Safely open a file
FILE* fopen_(const char* p, const char* m);

double clock_(void);

bool pairCompare(const pair<int, double>& firstElem, const pair<int, double>& secondElem);

// Sparse * dense inner product
inline double inner(map<int, double>* x, double* w)
{
	double res = 0;
	for (map<int, double>::iterator it = x->begin(); it != x->end(); it ++) {
		res += it->second * w[it->first];
	}
	return res;
}

inline double inner(double* x, double* y, int K)
{
	double res = 0;
	for (int k = 0; k < K; k ++) {
		res += x[k] * y[k];
	}
	return res;
}

inline double l2(double* x, double* y, int K)
{
	double res = 0;
	for (int k = 0; k < K; k ++) {
		res += (x[k] - y[k]) * (x[k] - y[k]);
	}
	return res;
}

inline double sigmoid(double x)
{
	return 1.0 / (1.0 + exp(-x));
}

inline double safeLog(double p)
{
	double x = log(1 + exp(p));
	if (std::isnan(x) or std::isinf(x)) {
		if (std::isnan(p) or std::isinf(p)) {
			printf("Bad prediction\n");
			exit(1);
		}
		return p;
	}
	return x;
}

inline double square(double x)
{
	return x * x;
}