#pragma once

#include "model.hpp"


class TransRec : public model
{
public:
	TransRec( corpus* corp, int K, int N, double lambda) 
			: model(corp)
			, K(K)
			, N(N)
			, lambda(lambda) {}

	~TransRec() {}

	void init();
	void clean_up();

	void parameters_from_flat(	double*    g,
								double***  H,
								double***  R,
								action_t   action);

	double distance(int productFrom, int productTo);

	void train(int max_iter, double learn_rate);
	virtual void optimize_embeddings(double learn_rate);
	
	void normalization(double** M, int ind);	
	string toString();
	
	void loadAsinToURL(string urlFilePath, map<string,string>& asin_to_url);
	void recommend(string urlFilePath, string tofilePath, int num, int topK);
	void sampleEdge(string urlFilePath, string tofilePath, int num);

	virtual void print();

	/* Parameters */
	double** H;  // Item embeddings
	double** R;  // Embeddings of each relationship type
	
	/* Hyper-parameters */
	int K;
	int N;
	double lambda;
};
