#include "common.hpp"


/// Safely open a file
FILE* fopen_(const char* p, const char* m)
{
	FILE* f = fopen(p, m);
	if (!f) {
		printf("Failed to open %s\n", p);
		exit(1);
	}
	return f;
}

bool pairCompare(const pair<int, double>& firstElem, const pair<int, double>& secondElem) 
{
	return firstElem.second < secondElem.second;
}

double clock_(void)
{
	timeval tim;
	gettimeofday(&tim, NULL);
	return tim.tv_sec + (tim.tv_usec / 1000000.0);
}
