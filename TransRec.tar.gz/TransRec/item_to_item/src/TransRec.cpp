#include "TransRec.hpp"


void TransRec::init()
{
	printf("  ===== TransRec_item_to_item =====\n");
	printf("  embedding dim. K = %d \n", K);
	printf("  #relation types N = %d \n", N);
	printf("  lambda = %f\n", lambda);
	fflush(stdout);

	// Total number of parameters
	NW = nItems * K + K * N;

	W = new double [NW];
	double range = 6.0 / sqrt(K);
	for (int i = 0; i < NW; i++) {
		W[i] = range - 2 * range * rand() / RAND_MAX;
	}

	parameters_from_flat(W, &H, &R, INIT);

	for (int i = 0; i < nItems; i ++) {
		normalization(H, i);
	}

	for (int n = 0; n < N; n ++) {
		normalization(R, n);
	}

	bestValidModel = new double [NW];
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}

	printf("==== %s ====\n", toString().c_str());
}

void TransRec::clean_up()
{
	parameters_from_flat(0, &H, &R, FREE);

	delete [] W;
	delete [] bestValidModel;
}

void TransRec::parameters_from_flat(double*    g,
									double***  H,
									double***  R,
									action_t   action)
{
	if (action == FREE) {
		delete [] *H;
		delete [] *R;
		return;
	}

	if (action == INIT) {
		*H = new double* [nItems];
		*R = new double* [N];
	}

	int ind = 0;

	for (int k = 0; k < nItems; k ++) {
		(*H)[k] = g + ind;
		ind += K;
	}

	for (int n = 0; n < N; n ++) {
		(*R)[n] = g + ind;
		ind += K;
	}

	if (ind != NW) {
		printf("Got incorrect index (%d != %d) at line %d of TransRec.cpp\n", ind, NW, __LINE__);
		exit(1);
	}
}

double TransRec::distance(int productFrom, int productTo)
{
	double dist = DBL_MAX;

	// Enumerate each type of relations
	for (int n = 0; n < N; n ++) {
		double l2_dist = 0;
		for (int k = 0; k < K; k ++) {
			l2_dist += square(H[productFrom][k] + R[n][k] - H[productTo][k]);
		}
		dist = min(dist, l2_dist);
	}

	return dist;
}

void TransRec::train(int max_iter, double learn_rate)
{
	best_valid_AUC = 0, best_test_AUC = 0, best_iter = 0;
	best_valid_Hit = 0, best_test_Hit = 0;

	for (int iter = 1; iter <= max_iter; iter ++) {

		optimize_embeddings(learn_rate);

		if (iter % 20 == 0) {
			print();
		}

		if (iter % 20 == 0) {
			double train_AUC, valid_AUC, test_AUC;
			double train_Hit, valid_Hit, test_Hit;

			trainValidTestAUC(train_AUC, valid_AUC, test_AUC, train_Hit, valid_Hit, test_Hit, 10, false);

			if (valid_AUC > best_valid_AUC) {
				best_valid_AUC = valid_AUC;
				best_test_AUC = test_AUC;
				best_iter = iter;
				copyBestValidModel();
			} else if (iter > best_iter + 200) {
				break;
			}

			if (valid_Hit > best_valid_Hit) {
				best_valid_Hit = valid_Hit;
				best_test_Hit = test_Hit;
			}

			printf("==================================== AUC:    Train = %f, Valid = %f, Test = %f\n", train_AUC, valid_AUC, test_AUC);
			printf("==================================== Hit@10: Train = %f, Valid = %f, Test = %f\n", train_Hit, valid_Hit, test_Hit);
			fflush(stdout);
		}
	}

	// copy back best parameters
	for (int w = 0; w < NW; w ++) {
		W[w] = bestValidModel[w];
	}

	printf("\n\n\nBest Valid AUC = %.4f, best Test AUC = %.4f\n", best_valid_AUC, best_test_AUC);
	printf("Best Valid Hit = %.4f, best Test Hit = %.4f\n", best_valid_Hit, best_test_Hit);
}

void TransRec::optimize_embeddings(double learn_rate)
{
	double l_dlStart = clock_();

	double* v_x_y = new double [K];
	double* v_x_yn = new double [K];

	//#pragma omp parallel for schedule(dynamic)
	for (int ind = 0; ind < validStart; ind ++) {
		edge* e = edges[ind];

		int x = e->productFrom;
		int y = e->productTo;
		int yn = valid_items[rand() % valid_items.size()];
		while(yn == y) {
			yn = valid_items[rand() % valid_items.size()];
		}

		double dist_min = DBL_MAX;
		int relation_pos = -1;
		for (int n = 0; n < N; n ++) {
			double l2_dist = 0;
			for (int j = 0; j < K; j ++) {
				l2_dist += square(H[x][j] + R[n][j] - H[y][j]);
			}
			if (l2_dist < dist_min) {
				dist_min = l2_dist;
				relation_pos = n;
			} 
		}

		dist_min = DBL_MAX;
		int relation_neg = -1;
		for (int n = 0; n < N; n ++) {
			double l2_dist = 0;
			for (int j = 0; j < K; j ++) {
				l2_dist += square(H[x][j] + R[n][j] - H[yn][j]);
			}
			if (l2_dist < dist_min) {
				dist_min = l2_dist;
				relation_neg = n;
			}
		}

		for (int k = 0; k < K; k ++) {
			v_x_y[k]  = R[relation_pos][k] + H[x][k] - H[y][k];
			v_x_yn[k] = R[relation_neg][k] + H[x][k] - H[yn][k];
		}

		// deri 
		double z = 1.0;
		for (int k = 0; k < K; k ++) {
			z += v_x_y[k] * v_x_y[k] - v_x_yn[k] * v_x_yn[k];
		}

		if (z > 0) {
			for (int k = 0; k < K; k ++) {
				H[x][k]  -= learn_rate * (v_x_y[k] - v_x_yn[k]);
				H[y][k]  -= learn_rate * (- v_x_y[k]);
				H[yn][k] -= learn_rate * (v_x_yn[k]);
				R[relation_pos][k] -= learn_rate / 1000 * (v_x_y[k] + lambda * R[relation_pos][k]);
				R[relation_neg][k] -= learn_rate / 1000 * (-v_x_yn[k] + lambda * R[relation_neg][k]);
			}
		}

		// normalization
		normalization(H, x);
		normalization(H, y);
		normalization(H, yn);
		// normalization(R, relation_pos);
		// normalization(R, relation_neg);

		if (not ((ind + 1) % 10000)) {
			// Print progress so that you can see that something is happening...
			printf("-");
			fflush(stdout);
		}
	}

	delete [] v_x_y; 
	delete [] v_x_yn;

	printf("took %f\n", clock_() - l_dlStart);
}

void TransRec::normalization(double** M, int ind)
{
	double sum = 0;
	for (int k = 0; k < K; k ++) {
		sum += M[ind][k] * M[ind][k];
	}
	sum = sqrt(sum);

	if (sum != 0) {
		for (int k = 0; k < K; k ++) {
			M[ind][k] /= sum;
		}
	}
}

void TransRec::print() {

	for (int n = 0; n < N; n ++) {
		printf("Relation %d: ", n);
		for (int k = 0; k < K; k ++) {
			printf("%.4f  ", R[n][k]);
		}
		printf("\n");
	}


	// vector<double> dist(N, 0);
	// vector<int> dist_cnt(N, 0);

	// for (int ind = 0; ind < validStart / 10; ind ++) {
	// 	edge* e = edges[ind];

	// 	double d = 0;
	// 	for (int k = 0; k < K; k ++) {
	// 		d += square(H[e->productFrom][k] - H[e->productTo][k]);
	// 	}
	// 	dist[e->relation] += sqrt(d);
	// 	dist_cnt[e->relation] += 1;
	// }

	// for (int n = 0; n < N; n ++) {
	// 	printf("Relation %d: Avg. pair dist = %f\n", n, dist[n] / dist_cnt[n]);
	// }

	vector<int> cnt(N, 0);
	for (int ind = 0; ind < validStart / 1000; ind ++) {
		edge* e = edges[ind];

		double dist = DBL_MAX;
		int re = -1;
		for (int n = 0; n < N; n ++) {
			double l2_dist = 0;
			for (int k = 0; k < K; k ++) {
				l2_dist += square(H[e->productFrom][k] + R[n][k] - H[e->productTo][k]);
			}
			if (l2_dist < dist) {
				dist = l2_dist;
				re = n;
			}
		}
		cnt[re] ++;
	}

	for (int n = 0; n < N; n ++) {
		printf("Relation %d: %d    ", n, cnt[n] * 1000);

		double sum = 0;
		for (int k = 0; k < K; k ++) {
			sum += R[n][k] * R[n][k];
		}
		printf("len = %f\n", sqrt(sum));
		/*
		if (total[n] < 300) {
		double range = 6.0 / sqrt(K);
		for (int k = 0; k < K; k ++) {
		R[n][k] = range - 2 * range * rand() / RAND_MAX;
		}
		normalization(R, n);
		printf("Relation %d reinitialized.\n", n);
		} */
	}

	// double total_dist = 0;
	// for (int i = 0; i < 1000000; i ++) {
	// 	int a = valid_items[rand() % valid_items.size()];
	// 	int b = valid_items[rand() % valid_items.size()];
	// 	double dist = 0;
	// 	for (int k = 0; k < K; k ++) {
	// 		dist += square(H[a][k] - H[b][k]);
	// 	}
	// 	total_dist += sqrt(dist);
	// }
	// printf("Avg. dist between items (1M pairs) = %f\n", total_dist/1000000);
}


void TransRec::loadAsinToURL(string urlFilePath, map<string,string>& asin_to_url)
{
	igzstream inURL;
	fprintf(stderr, "\n  Loading urls from %s\n", urlFilePath.c_str());
	inURL.open(urlFilePath.c_str());
	if (! inURL.good()) {
		fprintf(stderr, "Can't read urls from %s.\n", urlFilePath.c_str());
		exit(1);
	}
	string line;
	string asin, imUrl;
	while (getline(inURL, line)) {
		stringstream ss(line);
		ss >> asin >> imUrl;
		asin_to_url[asin] = imUrl;
	}
	inURL.close();
}

void TransRec::recommend(string urlFilePath, string tofilePath, int num, int topK)
{
	// load image urls first
	map<string, string> asin_to_url;
	loadAsinToURL(urlFilePath, asin_to_url);

	FILE* f = fopen_(tofilePath.c_str(), "w");
	fprintf(f, "<!-- Query to different clusters -->\n");
	fprintf(f, "<!DOCTYPE html><html><body>\n");
	fprintf(f, "<table width=\"100%%\" border=\"1\">\n");
	fprintf(f, "<tr>\n");
	fprintf(f, "  <th> Query </th>\n");
	for (int n = 0; n < N; n ++) {
		fprintf(f, "  <th>Relation %d</th>\n", n);
	}
	fprintf(f, "</tr>\n");


	for (int ind = 0; ind < num; ind ++) {
		fprintf(f, "<tr>\n");

		int productFrom = edges[rand() % validStart]->productFrom;
		string asin = corp->rItemIds[productFrom];
		while (asin_to_url.find(asin) == asin_to_url.end()) {
			productFrom = edges[rand() % validStart]->productFrom;
			asin = corp->rItemIds[productFrom];
		}

		fprintf(f, "   <td><a href=\"http://amazon.com/dp/%s\"><img src=\"%s\"></a></td>\n", asin.c_str(), asin_to_url[asin].c_str());

		for (int n = 0; n < N; n ++) {
			vector<pair<int, double>> rank;

			for (int j = 0; j < (int)valid_items.size(); j ++) {
				if (asin_to_url.find(corp->rItemIds[valid_items[j]]) != asin_to_url.end()) {
					double l2_dist = 0;
					for (int k = 0; k < K; k ++) {
						l2_dist += square(H[productFrom][k] + R[n][k] - H[valid_items[j]][k]);
					}
					rank.push_back(make_pair(valid_items[j], l2_dist));
				}
			}

			sort(rank.begin(), rank.end(), pairCompare);
			fprintf(f, "   <td>\n");
			fprintf(f, "      <table width=\"100%%\" border=\"1\">\n");
			fprintf(f, "        <tr>\n");
			for (int k = 0; k < topK; k ++) {
				string asin = corp->rItemIds[rank[k].first];
				fprintf(f, "         <td><a href=\"http://amazon.com/dp/%s\"><img src=\"%s\"></a></td>\n", asin.c_str(), asin_to_url[asin].c_str());
			}
			fprintf(f, "        </tr>\n");
			fprintf(f, "      </table>\n");
			fprintf(f, "   </td>\n");
		}

		fprintf(f, "</tr>\n");

		printf(".");
		fflush(stdout);
	}

	fprintf(f, "</table>\n");

	fprintf(f, "</body></html>\n");
	fclose(f);

	fprintf(stderr, "\n  %s generated!\n", tofilePath.c_str());
}

void TransRec::sampleEdge(string urlFilePath, string tofilePath, int num)
{
	// load image urls first
	map<string, string> asin_to_url;
	loadAsinToURL(urlFilePath, asin_to_url);

	FILE* f = fopen_(tofilePath.c_str(), "w");
	fprintf(f, "<!-- Query to different clusters -->\n");
	fprintf(f, "<!DOCTYPE html><html><body>\n");
	fprintf(f, "<table width=\"100%%\" border=\"1\">\n");

	for (int ind = 0; ind < num; ind ++) {
		fprintf(f, "<tr>\n");

		edge* e = edges[rand() % nEdges];
		string asin_from = corp->rItemIds[e->productFrom];
		string asin_to = corp->rItemIds[e->productTo];

		while(e->label == 0 || asin_to_url.find(asin_from) == asin_to_url.end() || asin_to_url.find(asin_to) == asin_to_url.end()) {
			e = edges[rand() % nEdges];
			asin_from = corp->rItemIds[e->productFrom];
			asin_to = corp->rItemIds[e->productTo];
		}

		fprintf(f, "   <td><a href=\"http://amazon.com/dp/%s\"><img src=\"%s\"></a></td>\n", asin_from.c_str(), asin_to_url[asin_from].c_str());
		fprintf(f, "   <td><a href=\"http://amazon.com/dp/%s\"><img src=\"%s\"></a></td>\n", asin_to.c_str(), asin_to_url[asin_to].c_str());

		fprintf(f, "</tr>\n");
	}

	fprintf(f, "</table>\n");

	fprintf(f, "</body></html>\n");
	fclose(f);

	fprintf(stderr, "\n  %s generated!\n", tofilePath.c_str());
}

string TransRec::toString()
{
	char str[10000];
	sprintf(str, "TransRec__K_%d_N_%d", K, N);
	return str;
}
