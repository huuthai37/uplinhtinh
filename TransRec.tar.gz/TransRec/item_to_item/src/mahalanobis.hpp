#pragma once

#include "WNN.hpp"

/**
Full-rank mahalanobis transform. Not really practical for features of any reasonable dimension.
*/
class mahalanobis : public WNN
{
public:
	mahalanobis (corpus* corp, double lambda) 
				: WNN(corp, lambda) {}

	~mahalanobis() {}

	void init();
	void clean_up();

	double distance(int productFrom, int productTo);

	void parameters_from_flat(	double*		g,
								double**	c,
								double***	M,
								action_t	action);

	double l_dl(double* grad);

	string toString();

	double** M;
};