#pragma once

#include "model.hpp"

#include "HLBFGS.h"

void evalfunc(int N, double* x, double* prev_x, double* f, double* g);
void newiteration(int iter, int call_iter, double* x, double* f, double* g, double* gnorm);


class WNN : public model
{
public:
	WNN( corpus* corp, double lambda) 
		: model(corp)
		, lambda(lambda)
	{		
		set<pair<int,int> > pos_neg_edge_set;
		for (int ind = 0; ind < validStart; ind ++) {
			edge* e = edges[ind];
			pos_neg_edges.push_back(new edge(e->productFrom, e->productTo, 1));
			pos_neg_edge_set.insert(make_pair(e->productFrom, e->productTo)); 
		}

		printf("  Sampling non-edges ");

		srand(0);
		while ((int)pos_neg_edges.size() < 2 * validStart) {

			int first = rand() % validStart;
			int second = rand() % validStart;
			int a = edges[first]->productFrom;
			int b = edges[first]->productTo;
			int c = edges[second]->productFrom;
			int d = edges[second]->productTo;

			if (a == d || c == b || !corp->isValidPair(a, d) || !corp->isValidPair(c, b)) {
				continue;
			}

			if (pos_neg_edge_set.find(make_pair(a, d)) != pos_neg_edge_set.end() || pos_neg_edge_set.find(make_pair(c, b)) != pos_neg_edge_set.end()) {
				continue;
			}

			pos_neg_edges.push_back(new edge(a, d, 0));
			pos_neg_edges.push_back(new edge(c, b, 0));

			pos_neg_edge_set.insert(make_pair(a, d));
			pos_neg_edge_set.insert(make_pair(c, b));

			// print progress
			if (!(pos_neg_edges.size() % 10000)) {
				printf(".");
			}
		}
		printf("\n  Size of positive + negative edges = %d\n", (int)pos_neg_edges.size());
		
		random_shuffle(pos_neg_edges.begin(), pos_neg_edges.end());

		best_valid_AUC = 0, best_test_AUC = 0, best_iter = 0;
		best_valid_Hit = 0, best_test_Hit = 0;
		stop = false;
	}

	~WNN() 
	{
		for (auto it = pos_neg_edges.begin(); it != pos_neg_edges.end(); it ++) {
			delete *it;
		}
	}

	void init();
	void clean_up();

	double distance(int productFrom, int productTo);

	void parameters_from_flat(	double*		g,
								double**	c,
								double**	logistic_edge,
								action_t	action);

	virtual double l_dl(double* grad);
	void train(int gradIterations);
	string toString();

	/* For traininig with LBFGS */
	bool stop;

	/* Model parameters */
	double* logistic_edge; // Logistic parameters (F)
	double* c; // Scale factor on distance transform
	
	/* Hyper-parameters */
	double lambda;

	/* Helper */
	vector<edge*> pos_neg_edges;
};
