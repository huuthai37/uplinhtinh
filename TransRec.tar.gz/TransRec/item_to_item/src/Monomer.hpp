#pragma once

#include "WNN.hpp"


class Monomer : public WNN
{
public:
	Monomer(corpus* corp, int K, int N, double lambda) 
			: WNN(corp, lambda)
			, K(K)
			, N(N) {}

	~Monomer() {}

	void init();
	void clean_up();

	void parameters_from_flat(  double*    g,
								double**   c,
								double**** E,
								double***  T,
								action_t   action);

	double l_dl(double* grad);

	void mapToKSpace();
	double distance(int productFrom, int productTo);
	void trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
							double& train_hit, double& valid_hit, double& test_hit, int POS, 
							bool sample);
	string toString();

	/* Parameters */
	double*** E; // Embedding matrices
	double**  T; // Weighting vectors 

	/* Hyper-parameters */
	int K;  // Dimensionality of latent spaces
	int N;	// Number of latent spaces (besides the anchor space)

	/* Helper */
	double*** k_space;
};
