#include "WNN.hpp"


/// HLBFGS regrettably requires that a global variable be passed around
WNN* gtc;

/// Required function by HLBFGS library: computes the log-probability and gradient
void evalfunc(int N, double* x, double* prev_x, double* f, double* g)
{
	if (gtc->stop) {
		for (int w = 0; w < N; w ++) {
			g[w] = 0;
		}
	} else {
		// Negative signs because we want gradient ascent rather than descent
		*f = -gtc->l_dl(g);
		for (int w = 0; w < N; w ++) {
			g[w] *= -1;
		}
	}
}

/// Required function by HLBFGS library: prints progress
void newiteration(int iter, int call_iter, double* x, double* f, double* g, double* gnorm)
{
	printf("X");

	if (iter % 20 == 0) {
		printf("Iter: %d, call_iter: %d \n", iter, call_iter);
		
		double train_AUC, valid_AUC, test_AUC;
		double train_Hit, valid_Hit, test_Hit;
		gtc->trainValidTestAUC(train_AUC, valid_AUC, test_AUC, train_Hit, valid_Hit, test_Hit, 10, false);

		printf("==================================== AUC:        Train = %f, Valid = %f, Test = %f\n", train_AUC, valid_AUC, test_AUC);
		printf("==================================== Recall@10:  Train = %f, Valid = %f, Test = %f\n", train_Hit, valid_Hit, test_Hit);
		fflush(stdout);

		if (valid_AUC > gtc->best_valid_AUC) {
			gtc->best_valid_AUC = valid_AUC;
			gtc->best_test_AUC = test_AUC;
			gtc->best_iter = iter;
			gtc->copyBestValidModel();
		} else if (iter > gtc->best_iter + 200) {
			gtc->stop = true;
		}

		if (valid_Hit > gtc->best_valid_Hit) {
			gtc->best_valid_Hit = valid_Hit;
			gtc->best_test_Hit = test_Hit;
		}
	}
}

void WNN::init()
{
	gtc = this;

	// Total number of parameters
	NW = 1 + featureDim;

	// Initialize parameters and latent variables
	W = new double [NW];
	for (int i = 0; i < NW; i++) {
		W[i] = 1.0 * rand() / INT_MAX;
	}
	W[0] = 0;

	parameters_from_flat(W, &c, &logistic_edge, INIT);

	bestValidModel = new double [NW];
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}

	printf("==== %s ====\n", toString().c_str());
}

void WNN::clean_up()
{
	parameters_from_flat(0, &c, &logistic_edge, FREE);
	delete[] W;
	delete [] bestValidModel;
}

/// Recover all parameters from a vector (g)
void WNN::parameters_from_flat(	double*		g,
								double**	c,
								double**	logistic_edge,
								action_t	action) // Do the vectors need to be initialized
{
	if (action == FREE) {
		return;
	}

	int ind = 0;

	*c = g + ind;
	ind ++;

	*logistic_edge = g + ind;
	ind += featureDim;

	if (ind != NW) {
		printf("Got incorrect index (%d != %d) at line %d of WNN.cpp\n", ind, NW, __LINE__);
		exit(1);
	}
}

double WNN::distance(int productFrom, int productTo)
{
	vector<pair<int, double> > sparsity = diff_feature(productFrom, productTo);

	double dist = 0;
	for (auto it = sparsity.begin(); it != sparsity.end(); it ++) {
		dist += square(logistic_edge[it->first] * it->second);
	}

	return dist;
}

/// Derivative of the log probability
double WNN::l_dl(double* grad)
{
	double l_dlStart = clock_();

	int NT = omp_get_max_threads();

	// Separate gradient vectors for each thread
	double** gradT = new double* [NT];
	double** dC = new double* [NT];
	double** dlogistic_edge = new double* [NT];

	double* llThread = new double [NT];
	for (int t = 0; t < NT; t ++) {
		llThread[t] = 0;
	}

	for (int t = 0; t < NT; t ++) {
		gradT[t] = new double [NW];
		for (int w = 0; w < NW; w ++) {
			gradT[t][w] = 0;
		}
		parameters_from_flat(gradT[t], dC + t, dlogistic_edge + t, INIT);
	}

	// #pragma omp parallel for schedule(dynamic)
	for (int ind = 0; ind < (int)pos_neg_edges.size(); ind ++) {
		int tid = omp_get_thread_num();
		
		edge* e = pos_neg_edges[ind];
		
		vector<pair<int, double> > sparsity = diff_feature(e->productFrom, e->productTo);

		double dist = 0;
		for (auto it = sparsity.begin(); it != sparsity.end(); it ++) {
			dist += square(logistic_edge[it->first] * it->second);
		}

		double pred = *c - dist;

		if (e->label) llThread[tid] += pred;
		llThread[tid] -= safeLog(pred);

		double deri = e->label - 1 / (1 + exp(-pred));

		*(dC[tid]) += deri;

		for (auto it = sparsity.begin(); it != sparsity.end(); it ++) {
			dlogistic_edge[tid][it->first] -= deri * 2 * logistic_edge[it->first] * square(it->second);
		}
	}

	double llTotal = 0;
	for (int t = 0; t < NT; t ++) {
		llTotal += llThread[t];
	}

	// Add up the gradients from all threads
	for (int w = 0; w < NW; w ++) {
		grad[w] = 0;
		for (int t = 0; t < NT; t ++) {
			grad[w] += gradT[t][w];
		}
	}

	for (int w = 1; w < NW; w ++) {
		llTotal -= lambda * W[w] * W[w];
		grad[w] -= 2 * lambda * W[w];
	}

	for (int t = 0; t < NT; t ++) {
		delete [] gradT[t];
		parameters_from_flat(0, dC + t, dlogistic_edge + t, FREE);
	}

	delete [] llThread;
	delete [] gradT;
	delete [] dC;
	delete [] dlogistic_edge;

	printf("took %f\n", clock_() - l_dlStart);

	return llTotal;
}

/// Train a model for "emIterations" with "gradIterations" of gradient descent at each step
void WNN::train(int gradIterations)
{
	stop = false;

	double parameter[20];
	int info[20];
	
	// Initialize
	INIT_HLBFGS(parameter, info);
	info[4] = gradIterations;
	info[5] = 0;
	info[6] = 0;
	info[7] = 0;
	info[10] = 0;
	info[11] = 1;
	HLBFGS(NW, 20, W, evalfunc, 0, HLBFGS_UPDATE_Hessian, newiteration, parameter, info);
	printf("\n");

	// Copy back best parameters
	for (int w = 0; w < NW; w ++) {
		W[w] = bestValidModel[w];
	}

	printf("\n\n\nBest Valid AUC = %.4f, best Test AUC = %.4f\n", best_valid_AUC, best_test_AUC);
	printf("Best Valid Hit = %.4f, best Test Hit = %.4f\n", best_valid_Hit, best_test_Hit);
}

string WNN::toString()
{
	char str[10000];
	sprintf(str, "WNN__lambda_%f", lambda);
	return str;
}
