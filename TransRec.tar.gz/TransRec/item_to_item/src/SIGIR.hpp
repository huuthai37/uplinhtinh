#pragma once

#include "WNN.hpp"


/* Please refer to the following paper
	Image-based recommendations on styles and substitutes
	Julian McAuley, Christopher Targett, Javen Shi, Anton van den Hengel
	SIGIR '15
*/
class SIGIR : public WNN
{
public:
	SIGIR(corpus* corp, int K, double lambda)
		 : WNN(corp, lambda)
		 , K(K) {}

	~SIGIR() {}

	void init();
	void clean_up();

	void parameters_from_flat(	double*		g,
								double**	c,
								double***	U,
								action_t	action);

	double l_dl(double* grad);
	double distance(int productFrom, int productTo);

	void mapToKSpace();
	void trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
							double& train_hit, double& valid_hit, double& test_hit, int POS, 
							bool sample);
	string toString();

	/* Parameters */
	double** U;

	/* Hyper-parameters */
	int K;

	/* Helper */
	double** k_space;
};
