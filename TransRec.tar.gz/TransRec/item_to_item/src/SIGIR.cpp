#include "SIGIR.hpp"

extern SIGIR* gtc;

void SIGIR::init()
{
	gtc = this;

	// Total number of parameters
	NW = 1 + featureDim * K;

	// Initialize parameters
	W = new double [NW];
	parameters_from_flat(W, &c, &U, INIT);

	// Initialize parameters
	W[0] = 0;
	for (int k = 0; k < K; k ++) {
		for (int i = 0; i < featureDim; i ++) {		
			U[k][i] = 1.0 - rand() * 2.0 / RAND_MAX;
		}
	}

	bestValidModel = new double [NW];
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}
	
	// Low-dimensional spaces (visual spaces)
	k_space = new double* [nItems];
	for (int i = 0; i < nItems; i ++) {
		k_space[i] = new double [K];
	}

	printf("==== %s ====\n", toString().c_str());
}

void SIGIR::clean_up()
{
	parameters_from_flat(0, &c, &U, FREE);

	delete [] W;
	delete [] bestValidModel;

	for (int i = 0; i < nItems; i ++) {
		delete k_space[i];
	}
	delete [] k_space;
}

void SIGIR::parameters_from_flat(	double* 	g, 
									double**	c, 
									double***	U, 
									action_t	action)
{
	if (action == FREE) {
		delete[] *U;
		return;
	}

	if (action == INIT) {
		*U = new double* [K];
	}

	int ind = 0;

	*c = g + ind;
	ind ++;

	for (int k = 0; k < K; k ++) {
		(*U)[k] = g + ind;
		ind += featureDim;
	}

	if (ind != NW) {
		printf("Got incorrect index (%d != %d) at line %d of mahalanobis.cpp\n", ind, NW, __LINE__);
		exit(1);
	}
}

void SIGIR::mapToKSpace()
{
	#pragma omp parallel for schedule(dynamic)
	for (int i = 0; i < nItems; i ++) {
		vector<pair<int, float> >& feat = corp->features[i];
		for (int k = 0; k < K; ++ k) {
			k_space[i][k] = 0;
			for (unsigned j = 0; j < feat.size(); j ++) {
				k_space[i][k] += U[k][feat[j].first] * feat[j].second;
			}
		}
	}
}

double SIGIR::distance(int productFrom, int productTo)
{
	double dist = 0;
	for (int k = 0; k < K; k ++) {
		dist += square(k_space[productFrom][k] - k_space[productTo][k]);
	}

	return dist;
}

/// Derivative of the log probability
double SIGIR::l_dl(double* grad)
{
	double l_dlStart = clock_();

	mapToKSpace();

	int NT = omp_get_max_threads();

	// Separate gradient vectors for each thread
	double**  gradT  = new double* [NT];
	double**  dC     = new double* [NT];
	double*** dU     = new double** [NT];

	double* llThread = new double [NT];
	for (int t = 0; t < NT; t ++) {
		llThread[t] = 0;
	}

	for (int t = 0; t < NT; t ++) {
		gradT[t] = new double [NW];
		for (int w = 0; w < NW; w ++) {
			gradT[t][w] = 0;
		}
		parameters_from_flat(gradT[t], dC + t, dU + t, INIT);
	}

	#pragma omp parallel for schedule(dynamic)
	for (int ind = 0; ind < (int)pos_neg_edges.size(); ind ++) {
		int tid = omp_get_thread_num();
		
		edge* e = pos_neg_edges[ind];

		double dist = 0;
		for (int k = 0; k < K; k ++) {
			dist += square(k_space[e->productTo][k] - k_space[e->productFrom][k]);
		}

		double pred = *c - dist;

		if (e->label) llThread[tid] += pred;
		llThread[tid] -= safeLog(pred);

		double deri = e->label - 1 / (1 + exp(-pred));

		*(dC[tid]) += deri;
		
		vector<pair<int, double> > sparsity = diff_feature(e->productFrom, e->productTo);
		for (int k = 0; k < K; k ++) {
			for (auto it = sparsity.begin(); it != sparsity.end(); it ++) {
				dU[tid][k][it->first] -= deri * 2 * (k_space[e->productTo][k] - k_space[e->productFrom][k]) * it->second;
			}
		}

		if (not ((ind + 1) % 100000)) {
			// Print progress so that you can see that something is happening...
			printf("-");
			fflush(stdout);
		}
	}

	double llTotal = 0;
	for (int t = 0; t < NT; t ++) {
		llTotal += llThread[t];
	}

	// Add up the gradients from all threads
	for (int w = 0; w < NW; w ++) {
		grad[w] = 0;
		for (int t = 0; t < NT; t ++) {
			grad[w] += gradT[t][w];
		}
	}

	for (int w = 1; w < NW; w ++) {
		llTotal -= lambda * W[w] * W[w];
		grad[w] -= 2 * lambda * W[w];
	}

	for (int t = 0; t < NT; t ++) {
		delete [] gradT[t];
		parameters_from_flat(0, dC + t, dU + t, FREE);
	}

	delete [] llThread;
	delete [] gradT;
	delete [] dC;
	delete [] dU;

	printf("took %f\n", clock_() - l_dlStart);

	return llTotal;
}

/// Compute the training, validation, and test error
void SIGIR::trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
								double& train_hit, double& valid_hit, double& test_hit, int POS, 
								bool sample)
{
	mapToKSpace();
	model::trainValidTestAUC(train_AUC, valid_AUC, test_AUC, train_hit, valid_hit, test_hit, POS, sample);
}

string SIGIR::toString()
{
	char str[10000];
	sprintf(str, "SIGIR__K_%d_lambda_%f", K, lambda);
	return str;
}
