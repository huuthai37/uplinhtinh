#include "TransRec_content.hpp"


void TransRec_content::init()
{
	printf("  ===== TransRec_item_to_item_content =====\n");
	printf("  embedding dim. K = %d \n", K);
	printf("  #relation types N = %d \n", N);
	printf("  lambda = %f\n", lambda);
	fflush(stdout);

	// Total number of parameters
	NW = featureDim * K + K * N;

	W = new double [NW];
	double range = 6.0 / sqrt(K);
	for (int i = 0; i < NW; i++) {
		W[i] = range - 2 * range * rand() / RAND_MAX;
	}

	parameters_from_flat(W, &E, &R, INIT);

	for (int n = 0; n < N; n ++) {
		normalization(R, n);
	}

	bestValidModel = new double [NW];
	for (int w = 0; w < NW; w ++) {
		bestValidModel[w] = W[w];
	}

	// Low-dimensional spaces (visual spaces)
	k_space = new double* [nItems];
	for (int i = 0; i < nItems; i ++) {
		k_space[i] = new double [K];
	}
}

void TransRec_content::clean_up()
{
	parameters_from_flat(0, &E, &R, FREE);

	delete [] W;
	delete [] bestValidModel;

	for (int i = 0; i < nItems; i ++) {
		delete k_space[i];
	}
	delete [] k_space;
}

void TransRec_content::parameters_from_flat(double*    g,
											double***  E,
											double***  R,
											action_t   action)
{
	if (action == FREE) {
		delete [] *E;
		delete [] *R;
		return;
	}

	if (action == INIT) {
		*E = new double* [K];
		*R = new double* [N];
	}

	int ind = 0;

	for (int k = 0; k < K; k ++) {
		(*E)[k] = g + ind;
		ind += featureDim;
	}

	for (int n = 0; n < N; n ++) {
		(*R)[n] = g + ind;
		ind += K;
	}

	if (ind != NW) {
		printf("Got incorrect index (%d != %d) at line %d of TransRec_content.cpp\n", ind, NW, __LINE__);
		exit(1);
	}
}

void TransRec_content::mapToKSpace()
{
	#pragma omp parallel for schedule(dynamic)
	for (int i = 0; i < nItems; i ++) {
		vector<pair<int, float> >& feat = corp->features[i];
		for (int k = 0; k < K; ++ k) {
			k_space[i][k] = 0;
			for (unsigned j = 0; j < feat.size(); j ++) {
				k_space[i][k] += E[k][feat[j].first] * feat[j].second;
			}
		}
	}
}

double TransRec_content::distance(int productFrom, int productTo)
{
	double dist = DBL_MAX;

	// Enumerate each type of relations
	for (int n = 0; n < N; n ++) {
		double l2_dist = 0;
		for (int k = 0; k < K; k ++) {
			l2_dist += square(k_space[productFrom][k] + R[n][k] - k_space[productTo][k]);
		}
		dist = min(dist, l2_dist);
	}

	return dist;
}

void TransRec_content::optimize_embeddings(double learn_rate)
{
	double l_dlStart = clock_();

	double* Ef_x_y = new double [K];
	double* Ef_x_yn = new double [K];

	for (int ind = 0; ind < validStart; ind ++) {
		edge* e = edges[ind];

		int x = e->productFrom;
		int y = e->productTo;
		int yn = valid_items[rand() % valid_items.size()];
		while(yn == y) {
			yn = valid_items[rand() % valid_items.size()];
		}

		vector<pair<int, double> > sparsity_x_y  = diff_feature(y, x);
		vector<pair<int, double> > sparsity_x_yn = diff_feature(yn, x);

		for (int k = 0; k < K; k ++) {
			Ef_x_y[k] = 0;
			for (auto it = sparsity_x_y.begin(); it != sparsity_x_y.end(); it ++) {
				Ef_x_y[k] += E[k][it->first] * it->second;
			}

			Ef_x_yn[k] = 0;
			for (auto it = sparsity_x_yn.begin(); it != sparsity_x_yn.end(); it ++) {
				Ef_x_yn[k] += E[k][it->first] * it->second;
			}
		}

		// Relation for the positive pair
		double dist_min = DBL_MAX;
		int relation_pos = -1;
		for (int n = 0; n < N; n ++) {
			double l2_dist = 0;
			for (int k = 0; k < K; k ++) {
				l2_dist += square(Ef_x_y[k] + R[n][k]);
			}
			if (l2_dist < dist_min) {
				dist_min = l2_dist;
				relation_pos = n;
			} 
		}

		// Relation for the negative pair
		dist_min = DBL_MAX;
		int relation_neg = -1;
		for (int n = 0; n < N; n ++) {
			double l2_dist = 0;
			for (int k = 0; k < K; k ++) {
				l2_dist += square(Ef_x_yn[k] + R[n][k]);
			}
			if (l2_dist < dist_min) {
				dist_min = l2_dist;
				relation_neg = n;
			}
		}

		for (int k = 0; k < K; k ++) {
			Ef_x_y[k]  += R[relation_pos][k];
			Ef_x_yn[k] += R[relation_neg][k];
		}

		// deri 
		double z = 1.0;
		for (int k = 0; k < K; k ++) {
			z += Ef_x_y[k] * Ef_x_y[k] - Ef_x_yn[k] * Ef_x_yn[k];
		}

		if (z > 0) {
			for (int k = 0; k < K; k ++) {
				for (auto it = sparsity_x_y.begin(); it != sparsity_x_y.end(); it ++) {
					E[k][it->first] -= learn_rate * (Ef_x_y[k] * it->second + lambda * E[k][it->first]);
				}

				for (auto it = sparsity_x_yn.begin(); it != sparsity_x_yn.end(); it ++) {
					E[k][it->first] -= learn_rate * (- Ef_x_yn[k] * it->second + lambda * E[k][it->first]);
				}

				R[relation_pos][k] -= learn_rate / 1000 * (Ef_x_y[k] + relation_reg * R[relation_pos][k]);
				R[relation_neg][k] -= learn_rate / 1000 * (-Ef_x_yn[k] + relation_reg * R[relation_neg][k]);
			}
		}

		if (not ((ind + 1) % 10000)) {
			// Print progress so that you can see that something is happening...
			printf("-");
			fflush(stdout);
		}
	}

	delete [] Ef_x_y;
	delete [] Ef_x_yn;

	printf("took %f\n", clock_() - l_dlStart);
}

void TransRec_content::print() {

	for (int n = 0; n < N; n ++) {
		printf("Relation %d: ", n);
		for (int k = 0; k < K; k ++) {
			printf("%.4f  ", R[n][k]);
		}
		printf("\n");
	}

	vector<int> cnt(N, 0);
	for (int ind = 0; ind < validStart / 1000; ind ++) {
		edge* e = edges[ind];

		double dist = DBL_MAX;
		int re = -1;
		for (int n = 0; n < N; n ++) {
			double l2_dist = 0;
			for (int k = 0; k < K; k ++) {
				l2_dist += square(k_space[e->productFrom][k] + R[n][k] - k_space[e->productTo][k]);
			}
			if (l2_dist < dist) {
				dist = l2_dist;
				re = n;
			}
		}
		cnt[re] ++;
	}

	for (int n = 0; n < N; n ++) {
		printf("Relation %d: %d    ", n, cnt[n] * 1000);

		double sum = 0;
		for (int k = 0; k < K; k ++) {
			sum += R[n][k] * R[n][k];
		}
		printf("len = %f\n", sqrt(sum));
	}
}

/// Compute the training, validation, and test error
void TransRec_content::trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
											double& train_hit, double& valid_hit, double& test_hit, int POS, 
											bool sample)
{
	mapToKSpace();
	model::trainValidTestAUC(train_AUC, valid_AUC, test_AUC, train_hit, valid_hit, test_hit, POS, sample);
}

string TransRec_content::toString()
{
	char str[10000];
	sprintf(str, "TransRec_Content__K_%d_N_%d_lambda_%f_relationReg_%f", K, N, lambda, relation_reg);
	return str;
}
