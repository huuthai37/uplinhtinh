#include "corpus.hpp"
#include "WNN.hpp"
#include "model.hpp"
#include "mahalanobis.hpp"
#include "SIGIR.hpp"
#include "Monomer.hpp"
#include "TransRec.hpp"
#include "TransRec_content.hpp"


void experiment_WNN(corpus* corp, double lambda, int iterations, char* model_path)
{
	WNN md(corp, lambda);
	md.init();
	md.train(iterations);

	md.saveModel((string(model_path) + "--" + corp->graphName + "--" + md.toString() + ".txt").c_str());
	md.clean_up();
}

void experiment_SIGIR(corpus* corp, int K, double lambda, int iterations, char* model_path)
{
	SIGIR md(corp, K, lambda);
	md.init();
	md.train(iterations);

	md.saveModel((string(model_path) + "--" + corp->graphName + "--" + md.toString() + ".txt").c_str());
	md.clean_up();
}

void experiment_Monomer(corpus* corp, int K, int N, double lambda, int iterations, char* model_path)
{
	Monomer md(corp, K, N, lambda);
	md.init();
	md.train(iterations);

	md.saveModel((string(model_path) + "--" + corp->graphName + "--" + md.toString() + ".txt").c_str());
	md.clean_up();
}

void experiment_TransRec(corpus* corp, int K, int N, double lambda, int iterations, char* model_path)
{
	TransRec md(corp, K, N, lambda);
	md.init();
	md.train(iterations, 0.1);

	md.saveModel((string(model_path) + "--" + corp->graphName + "--" + md.toString() + ".txt").c_str());
	md.clean_up();
}

void experiment_TransRec_content(corpus* corp, int K, int N, double lambda, double relation_reg, int iterations, char* model_path)
{
	TransRec_content md(corp, K, N, lambda, relation_reg);
	md.init();
	md.train(iterations, 0.1);

	md.saveModel((string(model_path) + "--" + corp->graphName + "--" + md.toString() + ".txt").c_str());
	md.clean_up();
}

int main(int argc, char** argv)
{
	srand(0);

	if (argc != 14) {
		printf("Files required are:\n");
		printf("  1: feature path\n");
		printf("  2: feature dim\n");

		printf("  3: metadata file\n");
		printf("  4: category prefix\n");
		printf("  5: layer\n");

		printf("  6: graph path\n");
		printf("  7: list of potential duplicate products to be merged\n");

		printf("  8: dimensionality (K)\n");
		printf("  9: #Components\n");
		printf(" 10: lambda\n");
		printf(" 11: relation_reg\n");

		printf(" 12: Iter\n");
		printf(" 13: model path\n");
		exit(0);
	}

	char* featurePath = argv[1];
	int dim = atoi(argv[2]);

	char* metaPath = argv[3];
	string ctpath(argv[4]);
	int layer = atoi(argv[5]);

	char* graphPath = argv[6];
	char* duplicatePath = argv[7];

	int K = atoi(argv[8]);
	int nComponents = atoi(argv[9]);
	double lambda = atof(argv[10]); 
	double relation_reg = atof(argv[11]);

	int iter = atoi(argv[12]);
	char* modelpath = argv[13];

	printf("{\n");
	printf("  \"corpus\": \"%s\",\n", argv[1]);

	vector<string> CTPath;
	int start = 0;
	while (true) {
		size_t found = ctpath.find('|', start);
		if (found == string::npos) {
			CTPath.push_back(ctpath.substr(start));
			break;
		} else {
			CTPath.push_back(ctpath.substr(start, found - start));
			start = found + 1;
		}
	}

	corpus corp(featurePath, dim, metaPath, CTPath, layer, graphPath, duplicatePath);

	// experiment_WNN(&corp, lambda, iter, modelpath);
	// experiment_SIGIR(&corp, K, lambda, iter, modelpath);
	// experiment_Monomer(&corp, K, nComponents, lambda, iter, modelpath);

	// experiment_TransRec(&corp, K, nComponents, lambda, iter, modelpath);
	experiment_TransRec_content(&corp, K, nComponents, lambda, relation_reg, iter, modelpath);

	printf("}\n");
	return 0;
}
