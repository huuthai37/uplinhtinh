#pragma once

#include "corpus.hpp"


class model
{
public:
	model(corpus* corp) : corp(corp)
	{
		nItems = corp->nItems;
		featureDim = corp->featureDim;

		// Get the edges
		for (set<pair<int,int> >::iterator it = corp->productGraph.begin(); it != corp->productGraph.end(); it ++) {
			int label = 1;
			int productFrom = it->first;
			int productTo = it->second;
			edges.push_back(new edge(productFrom, productTo, label));
		}		
		srand(0);
		random_shuffle(edges.begin(), edges.end());

		nEdges = edges.size();
		printf("  Edges: %lu\n", edges.size());
		
		// Partition the dataset
		double testFraction = 0.1;
		validStart = (int) ((1.0 - 2 * testFraction) * nEdges);
		testStart = (int) ((1.0 - testFraction) * nEdges);

		if (validStart < 1 or (testStart - validStart) < 1 or (nEdges - testStart) < 1) {
			printf("Didn't get enough edges (%d/%d/%d)\n", validStart, testStart, nEdges);
			exit(1);
		} else {
			printf("  Train edges: %d, Val edges: %d, Test edges: %d\n", validStart, testStart - validStart, nEdges - testStart);
		}

		// Valid items
		vector<bool> valid(nItems, false);
		for (int i = 0; i < (int)edges.size(); i ++) {
			valid[edges[i]->productFrom] = true; 
			valid[edges[i]->productTo] = true; 
		}
		for (int i = 0; i < nItems; i ++) {
			if (valid[i] && corp->itemCategoryId[i] != -1) {
				valid_items.push_back(i);
			}
		}
	}

	~model() 
	{
		for (auto it = edges.begin(); it != edges.end(); it ++) {
			delete *it;
		}
	}

	vector<pair<int, double> > diff_feature(int productFrom, int productTo);
	
	void copyBestValidModel();
	void saveModel(const char* savePath);
	void loadModel(const char* path);

	virtual double distance(int productFrom, int productTo) = 0;;
	virtual void trainValidTestAUC(	double& train_AUC, double& valid_AUC, double& test_AUC, 
									double& train_hit, double& valid_hit, double& test_hit, int POS, 
									bool sample);
	string toString();

	corpus* corp;
	int nItems; // Number of items
	int nEdges; // Number of edges
	int featureDim; 

	int validStart;
	int testStart;

	// Model parameters
	double* W; // Contiguous version of all parameters, i.e., a flat vector containing all parameters in order (useful for lbfgs)
	int NW;

	double best_valid_AUC, best_test_AUC, best_iter;
	double best_valid_Hit, best_test_Hit;
	double* bestValidModel;

	vector<edge*> edges;
	vector<int> valid_items;
};
